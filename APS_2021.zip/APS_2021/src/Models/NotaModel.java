package Models;

public class NotaModel {
    public double valor;   
}
