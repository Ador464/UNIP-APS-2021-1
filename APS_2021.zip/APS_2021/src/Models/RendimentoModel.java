package Models;

public class RendimentoModel {
    
    private AlunoModel aluno;
    private CursoModel curso;
    private NotaModel np1;
    private NotaModel np2;
    private NotaModel sub;
    private NotaModel exame;
    private boolean aprovado;
    private NotaModel media;
    
    /*public void mediaGraduacao(CursoModel tipo) {

        NotaModel mediaInicial = (this.np1 + this.np2) / 2.0;
        if (mediaInicial >= 7.0) {
            //aluno aprovado
        } 
        else {
            NotaModel mediaFinal = (mediaInicial + this.exame) / 2.0;
            if (mediaFinal >= 5.0) {
                //aluno aprovado
            } 
            else {
                //aluno reprovado
            }
        }
    }
    
     public void mediaPosGraduacao(CursoModel tipo) {

        NotaModel mediaInicial = (this.np1 + this.np2) / 2.0;
        if (mediaInicial >= 5.0) {
            //aluno aprovado
        } 
        else {
            NotaModel mediaFinal = (mediaInicial + this.exame) / 2.0;
            if (mediaFinal >= 5.0) {
                //aluno aprovado
            } 
            else {
                //aluno reprovado
            }
        }
    }
*/
}
