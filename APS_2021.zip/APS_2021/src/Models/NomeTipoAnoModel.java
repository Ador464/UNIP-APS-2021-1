package Models;

public class NomeTipoAnoModel {
    
    private CursoModel nome;
    private CursoModel tipo;
    private CursoModel ano;
    private AlunoModel ra;
    private AlunoModel np1;
    private AlunoModel np2;
    private AlunoModel sub;
    private AlunoModel exame;
    
    
}
