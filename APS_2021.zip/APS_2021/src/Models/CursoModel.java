package Models;

public class CursoModel {
    
    private String nomeCurso;
    private int anoCurso;
   
    public enum tipoCurso {
    graduacao(1), pos_graduacao(2);

    private int valor;
        tipoCurso(int valorOpcao){
        valor = valorOpcao;
}
    public int getValor(){
        return valor;
    }
}
    
    public CursoModel(String aNomeCurso, int aAnoCurso)
    {
        this.nomeCurso = aNomeCurso;
        this.anoCurso = aAnoCurso;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String aNomeCurso) {
        this.nomeCurso = aNomeCurso;
    }

    public int getAnoCurso() {
        return anoCurso;
    }

    public void setAnoCurso(int aAnoCurso) {
        this.anoCurso = aAnoCurso;
    }
    
}
