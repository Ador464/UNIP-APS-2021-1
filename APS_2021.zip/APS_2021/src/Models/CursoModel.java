package Models;

public class CursoModel {
    
    private String nomeCurso;
    private String tipoCurso;
    private int anoCurso;
    
    public CursoModel(String aNomeCurso, String aTipoCurso, int aAnoCurso)
    {
        this.nomeCurso = aNomeCurso;
        this.tipoCurso = aTipoCurso;
        this.anoCurso = aAnoCurso;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String aNomeCurso) {
        this.nomeCurso = aNomeCurso;
    }

    public String getTipoCurso() {
        return tipoCurso;
    }

    public void setTipoCurso(String aTipoCurso) {
        this.tipoCurso = aTipoCurso;
    }

    public int getAnoCurso() {
        return anoCurso;
    }

    public void setAnoCurso(int aAnoCurso) {
        this.anoCurso = aAnoCurso;
    }
    
}
