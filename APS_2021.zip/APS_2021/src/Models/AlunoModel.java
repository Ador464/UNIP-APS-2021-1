package Models;

public class AlunoModel {

    private String nome;
    private String id;

    public AlunoModel(String aNome) {
        this.nome = aNome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String aNome) {
        this.nome = aNome;
    }

    public String getId() {
        return id;
    }

    public void setId(String aId) {
        this.id = aId;
    }
}
