package Models;

public class AlunoModel {

    private String nome;
    private int id;
    private String ra;
    private double np1;
    private double np2;
    private double sub;
    private double exame;

    public AlunoModel(String aNome, int aId) {
        this.nome = aNome;
        this.id = aId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String aNome) {
        this.nome = aNome;
    }

    public int getId() {
        return id;
    }

    public void setId(int aId) {
        this.id = aId;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String aRa) {
        this.ra = aRa;
    }

    public double getNp1() {
        return np1;
    }

    public void setNp1(double aNp1) {
        this.np1 = aNp1;
    }

    public double getNp2() {
        return np2;
    }

    public void setNp2(double aNp2) {
        this.np2 = aNp2;
    }

    public double getSub() {
        return sub;
    }

    public void setSub(double aSub) {
        this.sub = aSub;
    }

    public double getExame() {
        return exame;
    }

    public void setExame(double aExame) {
        this.exame = aExame;
    }

    public void mediaGraduacao(CursoModel tipo) {

        double mediaInicial = (this.np1 + this.np2) / 2.0;
        if (mediaInicial >= 7.0) {
            //aluno aprovado
        } 
        else {
            double mediaFinal = (mediaInicial + this.exame) / 2.0;
            if (mediaFinal >= 5.0) {
                //aluno aprovado
            } 
            else {
                //aluno reprovado
            }
        }
    }
    
     public void mediaPosGraduacao(CursoModel tipo) {

        double mediaInicial = (this.np1 + this.np2) / 2.0;
        if (mediaInicial >= 5.0) {
            //aluno aprovado
        } 
        else {
            double mediaFinal = (mediaInicial + this.exame) / 2.0;
            if (mediaFinal >= 5.0) {
                //aluno aprovado
            } 
            else {
                //aluno reprovado
            }
        }
    }
}
