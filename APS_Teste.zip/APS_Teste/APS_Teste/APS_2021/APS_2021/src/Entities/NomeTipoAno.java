package Entities;

public class NomeTipoAno {
    
    private Curso nome;
    private Curso tipo;
    private Curso ano;
    private Aluno ra;
    private Aluno np1;
    private Aluno np2;
    private Aluno sub;
    private Aluno exame;
    
    
}
