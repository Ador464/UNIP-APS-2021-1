package Entities;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Notas {

    private Nota np1;
    private Nota np2;
    private Nota sub;
    private Nota exame;

    public Nota getNp1() {
        return np1;
    }

    public void setNp1(Nota aNp1) {
        this.np1 = aNp1;
    }

    public Nota getNp2() {
        return np2;
    }

    public void setNp2(Nota aNp2) {
        this.np2 = aNp2;
    }

    public Nota getSub() {
        return sub;
    }

    public void setSub(Nota aSub) {
        this.sub = aSub;
    }

    public Nota getExame() {
        return exame;
    }

    public void setExame(Nota aExame) {
        this.exame = aExame;
    }

    public String salvar() {

        try {
            FileWriter fw = new FileWriter("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\notas.csv", true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("np1: " + this.np1 + " , " + "np2: " + this.np2 + " , " + "sub: " + this.sub
                    + " , " + "exame: " + this.exame);
            pw.flush();
            pw.close();
            fw.close();

        } catch (IOException ex) {
            Logger.getLogger(Notas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return "Cadastrado com Sucesso";
    }

    public String carregar() {
        String dadosNotas = "";

        try {
            Scanner in = new Scanner(new FileReader("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\notas.csv"));
            while (in.hasNextLine()) {
                dadosNotas += in.nextLine() + "\n";
            }
        } catch (IOException ex) {
            Logger.getLogger(Notas.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dadosNotas;
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
