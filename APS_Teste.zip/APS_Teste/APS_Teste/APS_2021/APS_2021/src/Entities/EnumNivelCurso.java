package Entities;

public enum EnumNivelCurso {

    GRADUACAO(1), POS_GRADUACAO(2);

    private int valor;
        EnumNivelCurso(int valorOpcao){
        valor = valorOpcao;
}
    public int getValor(){
        return valor;
    }
}

