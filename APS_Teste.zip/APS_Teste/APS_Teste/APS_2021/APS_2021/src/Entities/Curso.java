package Entities;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Curso {

    private String nome;
    private int ano;
    private EnumNivelCurso nivel;

    public Curso() {
    }

    public Curso(String aNome, int aAno, EnumNivelCurso aNivel) {
        this.nome = aNome;
        this.ano = aAno;
        this.nivel = aNivel;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String aNome) {
        this.nome = aNome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int aAno) {
        this.ano = aAno;
    }

    public EnumNivelCurso getNivel() {
        return nivel;
    }

    public void setNivel(EnumNivelCurso nivel) {
        this.nivel = nivel;
    }

    public String salvar() {

        try {
            FileWriter fw = new FileWriter("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\curso.csv", true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("Nome: " + this.nome + " , " + "Ano: " + this.ano + " , " + "Nível: " + this.nivel);
            pw.flush();
            pw.close();
            fw.close();

        } catch (IOException ex) {
            Logger.getLogger(Curso.class.getName()).log(Level.SEVERE, null, ex);
        }

        return "Cadastrado com Sucesso";
    }

    public String carregar() {
        String dadosCurso = "";

        try {
            Scanner in = new Scanner(new FileReader("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\curso.csv"));
            while (in.hasNextLine()) {
                dadosCurso += in.nextLine() + "\n";
            }
        } catch (IOException ex) {
            Logger.getLogger(Curso.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dadosCurso;
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
