package Entities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/*import jdk.nashorn.internal.objects.NativeArray;*/

public class Aluno {
    private String id;
    private String nome;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String salvar() {
        
        try {
        FileWriter fw = new FileWriter("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\aluno.csv",true);
        PrintWriter pw = new PrintWriter(fw);
        pw.println("ID: " + this.id + " , " + "Nome: " + this.nome);
        pw.flush();
        pw.close();
        fw.close();
        
        } catch (IOException ex){
            Logger.getLogger(Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
                             
        return "Cadastrado com Sucesso";
    }
    
    public String carregar(){
        String dadosAlunos = ""; 
        
        try{
          Scanner in = new Scanner(new FileReader("C:\\Users\\Alves\\OneDrive\\Área de Trabalho\\01\\aluno.csv"));
            while (in.hasNextLine()) {
                dadosAlunos += in.nextLine()+"\n";
            }
        }catch (IOException ex){
            Logger.getLogger(Aluno.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return dadosAlunos;
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}