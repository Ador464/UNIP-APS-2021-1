package Models;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AlunoModel {

    private String nome;
    private String id;

    public AlunoModel(String aNome) {
        this.nome = aNome;
    }

    public AlunoModel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String aNome) {
        this.nome = aNome;
    }

    public String getId() {
        return id;
    }

    public void setId(String aId) {
        this.id = aId;
    }
    
    public String salvar() {
        
        try {
        FileWriter fw = new FileWriter("C:\\Alunos.txt", true);
        PrintWriter pw = new PrintWriter(fw);
        pw.println("Id: " + this.id + " , " + "Nome: " + this.nome);
        pw.flush();
        pw.close();
        fw.close();
        
        } catch (IOException ex){
            Logger.getLogger(AlunoModel.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                
        return "Aluno Cadastrado com Sucesso";
    }
}
