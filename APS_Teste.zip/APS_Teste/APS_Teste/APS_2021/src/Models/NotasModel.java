package Models;

public class NotasModel {
    private NotaModel np1;
    private NotaModel np2;
    private NotaModel sub;
    private NotaModel exame;
    
    public NotaModel getNp1() {
        return np1;
    }

    public void setNp1(NotaModel aNp1) {
        this.np1 = aNp1;
    }

    public NotaModel getNp2() {
        return np2;
    }

    public void setNp2(NotaModel aNp2) {
        this.np2 = aNp2;
    }

    public NotaModel getSub() {
        return sub;
    }

    public void setSub(NotaModel aSub) {
        this.sub = aSub;
    }

    public NotaModel getExame() {
        return exame;
    }

    public void setExame(NotaModel aExame) {
        this.exame = aExame;
    }
}
